package com.example.gson

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.StrictMode
import android.os.StrictMode.setThreadPolicy
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import timber.log.Timber
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL


data class Photo(
    val id: Long,
    val owner: String = "",
    val server : Int = 127081,
    val secret :String = "",
    val farm: Int= 0,
    val title : String = "",
    val ispublic : Int = 1,
    val isfriend:Int = 0,
    val isfamily: Int =1,
)

data class PhotoPage(
    val page : Int = 1,
    val pages : Int = 1,
    val perpage : Int = 100,
    val total :Int = 100,
    val photo : JsonArray
)
data class Wrapper(
    val photos : JsonObject,
    val stat: String = "ok"

)
class Adapter(
    private val context: Context,
    private val arrayList: ArrayList<String>,
    private val cellClickListener: MainActivity): RecyclerView.Adapter<Adapter.ViewHolder>(){

    class ViewHolder(view: View): RecyclerView.ViewHolder(view) {
        val image: ImageView = view.findViewById(R.id.image)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.rview_item,parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return arrayList.count()
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = arrayList[position]
        val inputStream : InputStream = URL(data).openStream()
        val bmp = BitmapFactory.decodeStream(inputStream)
        holder.image.setImageBitmap(bmp)

        holder.itemView.setOnClickListener {
            cellClickListener.onCellClickListener(data)
        }
    }
}

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        setThreadPolicy(policy)
        setContentView(R.layout.activity_main)
        Timber.plant(Timber.DebugTree())
        val cats = "https://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=ff49fcd4d4a08aa6aafb6ea3de826464&tags=cat&format=json&nojsoncallback=1"
        val list = arrayListOf<String>()
        val recyclerView:RecyclerView = findViewById(R.id.rView)

        Thread {
            val url =  URL(cats).openConnection() as HttpURLConnection
            val dataJson = url.inputStream.bufferedReader().readText()
            url.disconnect()

            val wrappedPhotos: Wrapper = Gson().fromJson(dataJson, Wrapper:: class.java)
            val firstPage : PhotoPage = Gson().fromJson(wrappedPhotos.photos, PhotoPage::class.java)
            val photos = Gson().fromJson(firstPage.photo, Array<Photo>:: class.java).toList()

            for(i in photos.indices){
                if(i.mod(5)==4){
                Timber.d(photos[i].toString())}
                list.add("https://farm${photos[i].farm}.staticflickr.com/${photos[i].server}/${photos[i].id}_${photos[i].secret}_z.jpg")
            }
            url.disconnect()

            runOnUiThread(){
                recyclerView.layoutManager = GridLayoutManager(this,2)
                recyclerView.adapter = Adapter(this, list,this)
            }
        }.start()

    }

    fun onCellClickListener(data: String) {
        val clipboard: ClipboardManager = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("",data)
        Timber.i(data)
        clipboard.setPrimaryClip(clip)
    }
}


